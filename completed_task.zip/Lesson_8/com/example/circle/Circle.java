package Lesson_8.com.example.circle;

/**
 * Заполните этот класс в соответсвии с заданием из лекции.
 */
public class Circle {
    double radius;
    public static boolean error = false;

    public Circle(double radius) {
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        if (radius > 0) {
            this.radius = radius;
        }
        else {
            error = true;
            throw new IllegalArgumentException("Radius must be greater than 0");

        }
    }
    public double getArea() {
        return Math.PI*Math.pow(radius, 2);
    }
}
